package com.example.test.widgets;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText stid;
    EditText scode;
    EditText smarck;

    TextView eid;
    TextView ecode;
    TextView emark;
    TextView egrd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        stid = findViewById(R.id.studentid);
        scode = findViewById(R.id.studentcode);
        smarck = findViewById(R.id.studentmark);

        eid = findViewById(R.id.textid);
        ecode = findViewById(R.id.textcode);
        emark = findViewById(R.id.markstexts);
        egrd = findViewById(R.id.totlamark);



        List<String> list =  new ArrayList<>();

    }


    public void showGrades(View view)


    {
        String stdID = stid.getText().toString();
        String stdCODE = scode.getText().toString();
        String stdMARK = smarck.getText().toString();
        double stdg = Double.parseDouble(stdMARK);


        eid.setText("Student ID:     " + stdID);
        ecode.setText("Course Code:  " + stdCODE);
        emark.setText("Total Marks: " + stdMARK);
        if(stdg >= 94 && stdg <= 100 ){
            egrd.setText("Grade:         A" );
        }
        else if(stdg >= 90&& stdg < 94 ){
            egrd.setText("Grade:         A-" );
        }
        else if(stdg >= 87 && stdg < 90 ){
            egrd.setText("Grade:         B+" );
        }
        else if(stdg >= 84 && stdg < 87 ){
            egrd.setText("Grade:         B" );
        }
        else if(stdg >= 80 && stdg < 84 ){
            egrd.setText("Grade:         B-" );
        }
        else if(stdg >= 77 && stdg < 80 ){
            egrd.setText("Grade:         C+" );
        }
        else if(stdg >= 74 && stdg < 77 ){
            egrd.setText("Grade:         C" );
        }
        else if(stdg >= 70 && stdg < 74 ){
            egrd.setText("Grade:         C-" );
        }
        else if(stdg >= 67 && stdg < 70 ){
            egrd.setText("Grade:         D+" );
        }
        else if(stdg >= 60 && stdg < 67 ) {
            egrd.setText("Grade:         A-");
        }
        else egrd.setText("Grade:         F");





    }
}
